package MSA;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.Map;

// InfoDataService.java
@Service
public class UserDataService {
    public List<Map<String, Object>> fetchAllData(String pkey) {
        return null;
        // Implement your data retrieval logic for Table1 (infoData) here
        // ...
    }
}
