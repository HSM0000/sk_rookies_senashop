package MSA;

public @interface RestController {

}
