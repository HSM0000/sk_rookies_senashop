package MSA;

public @interface Autowired {

}
