package MSA;

public @interface GetMapping {

}
