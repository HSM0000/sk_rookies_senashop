package MSA;

public @interface Service {

}
